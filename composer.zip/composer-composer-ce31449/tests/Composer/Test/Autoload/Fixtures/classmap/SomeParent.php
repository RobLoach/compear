<?php

namespace ClassMap;

abstract class SomeParent
{

}
