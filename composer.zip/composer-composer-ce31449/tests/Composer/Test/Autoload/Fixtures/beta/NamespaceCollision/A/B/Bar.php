<?php

namespace NamespaceCollision\A\B;

class Bar
{
    public static $loaded = true;
}
